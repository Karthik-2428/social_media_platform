<?php $this->load->view("layouts/header") ?>

<section>
    <div class="container">
  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success">
      <?php echo $this->session->flashdata('success'); ?>
    </div>
  <?php endif; ?>
</div>
<div class="container">
  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger">
      <?php echo $this->session->flashdata('error'); ?>
    </div>
  <?php endif; ?>
</div>
  <div class="container pt-2">
    <div class="card p-4">
      <div class="row">
        <div class="col-md-6 border-right">
          <form id="post_picture" action="" method="post" enctype="multipart/form-data">
            <div>
              <h4>Post a picture</h4>
            </div>
            <input type="file" class="post-pic"  name="post" />
          </form>
        </div>
        <div class="col-md-6">
          <form action="" method="post">
            <div class="form-group">
              <textarea placeholder="Enter what's in your mind today." name="matter" required class="form-control" ></textarea>
            </div>
            <div class="form-group">
              <button type="submit" name="post_matter" class="btn btn-primary" name="button">Post</button>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</section>

<section>
  <div class="container pt-2">
    <div class="row">
      <div class="col-md-6 pr-5 border-right">
        <h4>Pictures by the users</h4>
        <?php foreach ($post_pic as $post): ?>
          <div class="pt-5 pb-5">
            <div class="card p-4">
              <img src="<?php echo base_url('assets/uploads/'.$post->picture); ?>" class="img-fluid" alt="">
            </div>
            <div class="">
               Posted By:<?php echo $post->email ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="col-md-6 pl-5">
        <h4>Matters posted by the users</h4>
        <?php foreach ($post_matter as $post): ?>
          <div class="pt-5 pb-5">
            <div class="card p-4 quote">
                <?= $post->matter ?>
            </div>
            <div class="">
               Posted By:<?php echo $post->email ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<?php $this->load->view("layouts/footer") ?>
